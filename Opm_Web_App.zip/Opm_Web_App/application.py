# -*- coding: utf-8 -*-
"""
OPM Web Application Template
"""

import json
import plotly
from flask import Flask
from flask import render_template, request, redirect, url_for, send_file
from plotly.graph_objs import Bar

from tensorflow.keras import backend as K
from tensorflow.keras.models import model_from_json
from tensorflow.keras import losses
from tensorflow.keras import optimizers
import pandas as pd
import os
import itertools



def normalize_app(df):
    
    print('Processing....')
    
    df = df.groupby('EFDATET').sum()
    
    for col in list(df.columns):
       
        mean, std = df[col].mean(), df[col].std()

        df.loc[:, col] = (df[col] -mean) /(std + 1) 
    
    features = df.reset_index().iloc[:,1:]
    
    features = features.values
        
    return features 


def plot_pred_app(preds):
    
    train_label_mean = 4114.48
    
    train_label_std = 1422.759854762681
    
    unnormal_preds = preds * (train_label_std + 1) + train_label_mean
    
    merged = list(itertools.chain(*unnormal_preds))
    
    return merged 


application = Flask(__name__, static_url_path='')

upload_path = '/upload'

if not os.path.exists(upload_path):
            os.makedirs(upload_path) 

application.config['UPLOAD_FOLDER'] = '/upload'

  

@application.route('/', methods=['GET', 'POST'])
def upload_file():
    #filename = 'example.csv'
    if request.method == 'POST':
        # check if the post request has the file part
        file = request.files['file'] 
        
        filename = file.filename
        
        file.save(os.path.join('/upload', filename))
                
        return redirect(url_for('go'))
    else:
        return render_template('master.html')
    
@application.route('/', methods=['GET', 'POST'])
def downloadFile ():
    #C:/Users/604070/Desktop/Files/
    if request.method == 'GET':
        #For windows you need to use drive name [ex: F:/Example.pdf]
        path = url_for('static', filename="input/df_input.csv")
        return send_file(path, as_attachment=True), render_template('master.html')

@application.route('/go', methods=['GET', 'POST'])
def go():
     
    web_input = pd.read_csv('/upload/df_input.csv')

    app_features = normalize_app(web_input.iloc[:,1:])
    
    model_file = os.path.join('static/model/', 'model.json')
    
    json_file = open(model_file, 'r')
    
    K.clear_session()
    
    loaded_model_json = json_file.read()
    
    json_file.close()
    
    loaded_model = model_from_json(loaded_model_json)    
    
    loaded_model.load_weights(os.path.join('static/weights/','best.h5'))
    
    sgd = optimizers.SGD(lr=0.01)
    
    loaded_model.compile(loss=losses.mean_squared_error,
                  optimizer=sgd,
                  metrics=['mean_squared_error'])    
        
    results = loaded_model.predict(app_features)
    
    results = plot_pred_app(results)
    
    period = ['1', '2', '3', '4', '5', '6', '7', '8']
    
    #test = [10, 50, 10, 8, 6, 45, 3, 4]
    
    bar_chart = Bar(x = period, y = results)
    
    bar_json = json.dumps(bar_chart, cls=plotly.utils.PlotlyJSONEncoder)
    
    print(bar_json)
     
    return render_template('go.html', bar_json = bar_json) 


    
if __name__ == "__main__":
    application.run(debug=False)
